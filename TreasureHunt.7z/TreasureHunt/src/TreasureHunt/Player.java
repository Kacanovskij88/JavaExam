package TreasureHunt;

public class Player extends MapDir {
	
	public void place() {
	}
	public void win() {
		System.out.println("if you continue to go to the East you will find the treasure");
		
	}
	public void lose() {
		System.out.println("You died: game over");
		

	}
	
	

}
