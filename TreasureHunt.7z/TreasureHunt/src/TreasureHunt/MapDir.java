package TreasureHunt;

public class MapDir extends Comp {


	
	public void start() {
		System.out.println("start point Barren Moore");
		System.out.println("Grey foggy clouds are comming on you");
		System.out.println("type: 1 - north, 2 - east, 3 - west, 4 - south");
	}
	
	public void north() {
		System.out.println("destination North");
		System.out.println("you went to Alligators nest");
	
	}
	
	public void east() {
		System.out.println("destination East");
		System.out.println("you  are on the right way");
	}
	
	public void west() {
		System.out.println("destination West");
		System.out.println("it is the way out of the swamp");
	}
	
	public void south() {
		System.out.println("destination South");
		System.out.println("you entering Indian territory");
	}
}
	
	
	

